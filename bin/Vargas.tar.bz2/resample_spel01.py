#!/usr/bin/env python
#
# Resample spel01 observations on a 100 year regular spacing
#
# 4/7/2024 Machiel Bos, Santa Clara
#===============================================================================

import sys
import os
import math
import numpy as np

#===============================================================================
# Main program
#===============================================================================

def main():

    #--- Read observations
    with open('raw_files/spel01.txt','r') as fp:
        lines = fp.readlines()

    data = {}
    for line in lines:
        cols = line.split()
        t = float(cols[0])
        y = float(cols[1])

        t = int(math.floor((t+50.0)*0.01))*100
        if t in data.keys():
            data[t].append(y)
        else:
            data[t] = [y]

   
    t_lst = list(data.keys()) 
    t = np.array(t_lst) 
    t0 = np.min(t)
    t1 = np.max(t)

    fp_out = open('obs_files/spel01.txt','w')
    fp_out.write('# sampling period 100.0\n')
    fp_out.write('# TimeUnit years\n')
    fp_out.write('# PhysicalUnit ??\n')
    n = (t1-t0)//100 + 1
    for i in range(0,n):
        t = t0 + i*100
        if t in data.keys():
            y_mean = np.mean(data[t])
            fp_out.write('{0:6.0f} {1:5.1f}\n'.format(t,y_mean))
    fp_out.close()

    

if __name__=='__main__':
    main()
