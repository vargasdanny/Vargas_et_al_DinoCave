DataFile              spel01.txt
DataDirectory         fin_files
TS_format             gen
interpolate           no
ScaleFactor           1.0
PhysicalUnit          mm
TimeUnit              year
Verbose               no
