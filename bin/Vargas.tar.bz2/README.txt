
The script 'resample_spel01.py' is used to create a regularly spaced
time series of spel01.txt (spacing 100 years)

To analyse the data, edit noise model in estimatetrend.ctl and run:

estimatetrend -graph
estimatespectrum -model -graph 
